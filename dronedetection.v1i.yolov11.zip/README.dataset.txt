# dronedetection > 2023-08-27 12:58am
https://universe.roboflow.com/tu-delft-ycvav/dronedetection-bhesw

Provided by a Roboflow user
License: CC BY 4.0

