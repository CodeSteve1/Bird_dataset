# bird detection > 2022-02-12 11:45pm
https://universe.roboflow.com/ryu-myoungwoo/bird-detection-zqcdr

Provided by a Roboflow user
License: CC BY 4.0

